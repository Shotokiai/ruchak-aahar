// pages/api/profile/index.js
// GET  → fetch current user's profile
// POST → save/update onboarding data (age, weight, food pref, etc.)

import { getServerSession } from 'next-auth/next';
import { authOptions }      from '../auth/[...nextauth]';
import { supabaseAdmin }    from '../../../lib/supabase-admin';
import { calcCalories }     from '../../../lib/calorie';

export default async function handler(req, res) {
  const session = await getServerSession(req, res, authOptions);
  if (!session) return res.status(401).json({ error: 'Not authenticated' });

  const userId = session.user.supabaseId;

  // ── GET ──────────────────────────────────────────────────────────
  if (req.method === 'GET') {
    const { data, error } = await supabaseAdmin
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json(data);
  }

  // ── POST (save onboarding) ────────────────────────────────────────
  if (req.method === 'POST') {
    const {
      age, weight_kg, height_cm,
      food_pref, allergies,
      activity_level, body_goal,
      gender = 'm',
    } = req.body;

    // Calculate calories server-side — never trust the client
    const { maintenance, target } = calcCalories(
      age, weight_kg, height_cm,
      activity_level, body_goal, gender
    );

    const { data, error } = await supabaseAdmin
      .from('profiles')
      .update({
        age, weight_kg, height_cm,
        food_pref, allergies,
        activity_level, body_goal,
        maintenance_cal: maintenance,
        target_cal:      target,
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ profile: data, maintenance, target });
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).json({ error: 'Method not allowed' });
}
