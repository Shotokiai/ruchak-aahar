// pages/api/auth/[...nextauth].js
import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';
import { supabaseAdmin } from '../../../lib/supabase-admin';

export const authOptions = {
  providers: [
    GoogleProvider({
      clientId:     process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    }),
  ],

  secret: process.env.NEXTAUTH_SECRET,

  session: { strategy: 'jwt' },

  callbacks: {
    // Called after successful sign-in
    async signIn({ user, account }) {
      if (account?.provider !== 'google') return false;

      // Upsert the user in Supabase profiles table
      // (the trigger handles brand-new users, but upsert is safe for returning users)
      const { error } = await supabaseAdmin
        .from('profiles')
        .upsert(
          {
            id:         user.id,   // NOTE: NextAuth Google ID ≠ Supabase UUID
            name:       user.name,
            email:      user.email,
            avatar_url: user.image,
          },
          { onConflict: 'email' }   // use email as the unique key here
        );

      if (error) console.error('Supabase upsert error:', error.message);
      return true;
    },

    // Attach Supabase profile id to JWT
    async jwt({ token, user, account }) {
      if (account?.provider === 'google' && user?.email) {
        const { data: profile } = await supabaseAdmin
          .from('profiles')
          .select('id, name, avatar_url')
          .eq('email', user.email)
          .single();

        if (profile) {
          token.supabaseId  = profile.id;
          token.name        = profile.name;
          token.picture     = profile.avatar_url;
        }
      }
      return token;
    },

    // Expose supabaseId to the client session
    async session({ session, token }) {
      session.user.supabaseId = token.supabaseId;
      return session;
    },
  },

  pages: {
    signIn: '/',          // redirect here if not logged in
    error:  '/?error=1',
  },
};

export default NextAuth(authOptions);
