// components/App.js
// Barrel export — the actual app is pages/index.js (Next.js convention)
// This file exists so the import in pages/index.js resolves correctly.

// NOTE: When converting to a proper Next.js project, move the App()
// function from pages/index.js here and import it below.

export { default } from '../pages/_app';
